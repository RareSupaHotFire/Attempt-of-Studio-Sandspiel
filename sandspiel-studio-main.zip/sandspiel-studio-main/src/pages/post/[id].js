import { useRouter } from "next/router.js";
import Browse from "../browse.js";

function Post() {
  return Browse();
}
export default Post;
