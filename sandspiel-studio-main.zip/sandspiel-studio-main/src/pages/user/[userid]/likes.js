import Browse from "../../browse.js";

export default Browse;
