/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect, useRef } from "react";
const spinners = [
  "←↖↑↗→↘↓↙",
  "▖▘▝▗",
  "▌▀▐▄",
  "◢◣◤◥",
  "◰◳◲◱",
  "◴◷◶◵",
  "◐◓◑◒",
  "|/-\\",
  ["◜ ", " ◝", " ◞", "◟ "],
  "◇◈◆",
  "⣾⣽⣻⢿⡿⣟⣯⣷",
  "⡀⡁⡂⡃⡄⡅⡆⡇⡈⡉⡊⡋⡌⡍⡎⡏⡐⡑⡒⡓⡔⡕⡖⡗⡘⡙⡚⡛⡜⡝⡞⡟⡠⡡⡢⡣⡤⡥⡦⡧⡨⡩⡪⡫⡬⡭⡮⡯⡰⡱⡲⡳⡴⡵⡶⡷⡸⡹⡺⡻⡼⡽⡾⡿⢀⢁⢂⢃⢄⢅⢆⢇⢈⢉⢊⢋⢌⢍⢎⢏⢐⢑⢒⢓⢔⢕⢖⢗⢘⢙⢚⢛⢜⢝⢞⢟⢠⢡⢢⢣⢤⢥⢦⢧⢨⢩⢪⢫⢬⢭⢮⢯⢰⢱⢲⢳⢴⢵⢶⢷⢸⢹⢺⢻⢼⢽⢾⢿⣀⣁⣂⣃⣄⣅⣆⣇⣈⣉⣊⣋⣌⣍⣎⣏⣐⣑⣒⣓⣔⣕⣖⣗⣘⣙⣚⣛⣜⣝⣞⣟⣠⣡⣢⣣⣤⣥⣦⣧⣨⣩⣪⣫⣬⣭⣮⣯⣰⣱⣲⣳⣴⣵⣶⣷⣸⣹⣺⣻⣼⣽⣾⣿",
  "⠁⠂⠄⡀⢀⠠⠐⠈",
];

const spinner = spinners[2];

function useInterval(callback, delay) {
  const savedCallback = useRef();

  // Remember the latest callback.
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // Set up the interval.
  useEffect(() => {
    function tick() {
      savedCallback.current();
    }
    if (delay !== null) {
      let id = setInterval(tick, delay);
      return () => clearInterval(id);
    }
  }, [delay]);
}

function Spinner() {
  let [count, setCount] = useState(0);

  useInterval(() => {
    // Your custom logic here
    setCount((count + 1) % spinner.length);
  }, 100);

  return (
    <>
      <span>{spinner[count]}</span>
      <style jsx>
        {`
          span {
            position: absolute;
            left: 5px;
            top: 5px;
          }
        `}
      </style>
    </>
  );
}
export default Spinner;
